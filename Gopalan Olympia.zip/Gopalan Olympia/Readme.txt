* languages used: html, css, bootstra4, jquery, php, mysql
* frontend:
created landing page using bootstrap4 , html, css , javascript
* created 4  database :
1. sandbox
2. user_db
3. autoloadform
4. contactform
user_db: inside registration form data stored.
autoloadform: inside enquire now form data stored.
contactform: inside contact form data stored
* backend
4 pages created please check inside folder(backend)
1. register
2. login
3. dashboard
4. profile
