<?php

  $name = $_POST['name'];
  $number = $_POST['number'];
  $email = $_POST['email'];

  $bhk = $_POST['bhk'];
  $visit = $_POST['visit'];
  $conn =mysqli_connect("localhost", "root", "","autoloadform" )or die("connection failed");
  $sql = "INSERT INTO enquire(name, number, email, bhk, visit) VALUES('{$name}','{$number}','{$email}','{$bhk}','{$visit}')";
  $result=mysqli_query($conn,$sql) or die("Query failed");
  header("location:thankyou.php");
  mysqli_close($conn);


//using session
  // session_start();
  // if(isset($_POST['submit'])){
  //   if(empty($_POST['name'])||empty(($_POST['number'])) || empty(($_POST['email']))|| empty(($_POST['$bhk'])) || empty(($_POST['$visit']))){
  //     $_SESSION['res']="all the field required";
  //     header("location:thankyou.php");
  //   }
  //   else if(!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){
  //     $error ="Enter your valid email address";
  //     $_SESSION['res']=$error;
  //     header("location:thankyou.php");
  //   }
  //   $conn =mysqli_connect("localhost", "root", "","autoloadform" )or die("connection failed");
  //   $result = $conn->query("INSERT INTO 'enquire'(name, number, email, bhk, visit) VALUES('$name','$number','$email','$bhk','$visit')");
  //   // $sql = "INSERT INTO enquire(name, number, email, bhk, visit) VALUES('{$name}','{$number}','{$email}','{$bhk}','{$visit}')";
  //   // $result=mysqli_query($conn,$sql) or die("Query failed");
   
  //   if($result==true){
  //     $_SESSION['res']='Thank you for contacting us !';
  //     header("location: thankyou.php");
  //     mysqli_close($conn);
  //   }

  // }



?>