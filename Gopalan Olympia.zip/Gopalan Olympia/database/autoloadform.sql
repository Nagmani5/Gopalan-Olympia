-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 06, 2022 at 04:28 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `autoloadform`
--

-- --------------------------------------------------------

--
-- Table structure for table `enquire`
--

CREATE TABLE `enquire` (
  `name` varchar(10) NOT NULL,
  `number` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `bhk` varchar(10) NOT NULL,
  `visit` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `enquire`
--

INSERT INTO `enquire` (`name`, `number`, `email`, `bhk`, `visit`) VALUES
('', '0', '{email}', '{bhk}', '{visit}'),
('', '0', '{email}', '{bhk}', '{visit}'),
('', '0', '{email}', '{bhk}', '{visit}'),
('nagmani', '2147483647', '{email}', '{bhk}', '{visit}'),
('nagmani', '9900990099', '{email}', '{bhk}', '{visit}'),
('nagmani', '9900990099', '{email}', '{bhk}', '{visit}'),
('', '', '', '', ''),
('priya', '7700990088', 'priyaa@testing.com', '2bhk', 'Yes'),
('', '', '', '', ''),
('', '', '', '', ''),
('', '', '', '', ''),
('', '', '', '', ''),
('', '', '', '', ''),
('', '', '', '', ''),
('', '', '', '', ''),
('', '', '', '', ''),
('', '', '', '', ''),
('', '', '', '', ''),
('', '', '', '', ''),
('', '', '', '', ''),
('nagmani', '9900990099', 'priyaa@testing.com', '2bhk', 'Yes'),
('', '', '', '', ''),
('sanjana', '08792470741', 'sanjana@testing.com', '3bhk', 'Yes');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
