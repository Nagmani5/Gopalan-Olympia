<?php session_start();?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Sports City in Off Mysore Road - Gopalan Olympia</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/images/fevicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link
    href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
    rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <!--bootstrap 4 link-->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  <!--end-->
 <style>
 .fixed-menu{
  top:0;
  
width:100%;
 background: #fff;
 margin-right:40px

}
</style>
  <script>
    $(document).ready(function(){
     $('#exampleModal').modal('show');
    });
     </script>
<body>



  <!-- ======= Top Bar ======= -->


  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">




      
      <nav id="navbar" class="navbar">
      <a href="index.php" class="logo"><img src="assets/images/logo/logo.png" alt="" class="img-fluid" style="width:100%;height:50%"></a>
      <a href="index.php" class="logo"><img src="assets/images/logo/logo-olympia.png" alt="" class="img-fluid"></a>
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#Overview">Overview</a></li>
          <li><a class="nav-link scrollto" href="#services">Configuration</a></li>
          <li><a class="nav-link scrollto " href="#portfolio">Amenities</a></li>
          <li><a class="nav-link scrollto" href="#pricing">Gallery</a></li>


          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>

    </div>
  </header>
  <!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <!-- <div class="container position-relative" data-aos="fade-up" data-aos-delay="500">
      <h1>Welcome to Day</h1>
      <h2>We are team of talented designers making websites with Bootstrap</h2>
      <a href="#about" class="btn-get-started scrollto">Get Started</a>
    </div> -->
  </section><!-- End Hero -->
  <section id="Overview">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h1 class="header_g">Gopalan Olympia Transforming Kumbalgodu</h1>
          <h2 class="apt">Luxurious 2 & 3 BHK Apartments <br><strong>Kumbalgodu, Mysore Road</strong></h2>

          <p>Gopalan Olympia Ranging from 2bhk & 3bhk and multiple floor plans, Gopalan Olympia Caters to different
            lifestyle needs of different residents. From Sports to Shopping, from Peaceful walkwaysto zen like
            meditation centres, the centres, the project blend style with fumn to make homes that promise a lifetime of
            happy Moments.</p>
          <p>The complex features upscale facilities and amenities hence helping the dwellers to live an easy lifestyle.
            The project is located in a place, suitable for nature loving persons and loved by all. The project is
            mainly made with the focus of providing the customers with complete satisfaction.</p>


          <center><button type="button" class="btn btn-dark" data-toggle="modal" data-target="#exampleModal">Get In Touch</button></center>
        </div>
      </div>
    </div>
  </section>


  <!--autoload form-->
  <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Open modal for @mdo</button> -->


<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Enquire Now</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       
        <?php
        if(isset($_SESSION['res'])):?>
        <div class="alert alert-warning" role="alert">
          <?php echo $_SESSION['res']; ?>
  </div>
  <?php endif ;?>

        <form action="connect.php" method="POST">
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Name</label>
            <input type="text" class="form-control" id="recipient-name" Name="name">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Phone</label>
            <input type="text" class="form-control" id="recipient-name" name="number">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Email</label>
            <input type="text" class="form-control" id="recipient-name" name="email">
          </div>
          <!-- <div class="form-group">
            <label for="message-text" class="col-form-label">Message:</label>
            <textarea class="form-control" id="message-text"></textarea>
          </div> -->
          <p>I would like to know more about</p>
          <div class="form-check form-check-inline">
           
            <input class="form-check-input" type="radio" name="bhk" id="inlineRadio1" value="2bhk">
            <label class="form-check-label" for="inlineRadio1">2bhk</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="bhk" id="inlineRadio2" value="3bhk">
            <label class="form-check-label" for="inlineRadio2">3bhk</label>
          </div>
       
          <p>Interested in a site visit?</p>
          <div class="form-check form-check-inline">
           
            <input class="form-check-input" type="radio" name="visit" id="inlineRadio1" value="Yes">
            <label class="form-check-label" for="inlineRadio1">Yes</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="visit" id="inlineRadio2" value="No">
            <label class="form-check-label" for="inlineRadio2">No</label>
          </div><br><br>
          <div class="modal-footer">
     
            <button name="submit" class="btn btn-dark">Submit</button>
          </div>
        </form>
      </div>
    
    </div>
  </div>
</div>
<!--end-->
  <section class="section__offer py-5" id="section-offer">
    <div class="row">
      <div class="col-md-6">
        <div class="wrap__offer container py-3">

          <div class="container">

            <article class="col-md-6 wrap__article">

              <header class="text-center">

                Gopalan Olympia Offers

              </header><br>

              <ul class="py-3">

       

                <li>&#10003 OC Received + No GST</li>

                <li> &#10003 Ready to move-in</li>

                <li> &#10003 Upgraded Lifestyle</li>

                <li> &#10003 Easy Home Loans With Easy EMI's</li>

             

              </ul>

              <footer>

                <center> 
              <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal">  Download Brochure</button>
            </center>

              </footer>

            </article>

          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="wrap__offer container py-3">

          <div class="container">

            <article class="col-md-6 wrap__article">

              <header class="offer__whatsApp-header mb-2">

                GET FULL OFFER DETAILS

              </header>
              <div class="offer__call-body">

                <a class="phone-number" href="tel:08049314931"><i class="bx bx-phone"></i>080 49314931</a>

              </div>

            
                <h2 style="color:#fff; text-align:center; font-size: 25px; font-weight: bold;">
                  GET FULL OFFER DETAILS</h2>


                <div class="offer__whatsApp-body">
                  <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal">Enquire Now</button>

                </div>

              </div>




            </article>
          </div>
        </div>
  </section>
  <main id="main">

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
          <span>CONTACT US</span>
          <h2>CONTACT US</h2>

        </div>



        <div class="row" data-aos="fade-up">

          <div class="col-lg-6 ">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6541.324917486087!2d77.44789621018019!3d12.875856269943663!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae38a22d6e10cb%3A0x4b9602a97c884931!2sGopalan%20Olympia%2C%20Kumbalagodu-Gollahalli%20Rd%2C%20Kumbalgodu%2C%20Karnataka%20560060!5e0!3m2!1sen!2sin!4v1617347079779!5m2!1sen!2sin"
              width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
          </div>

          <div class="col-lg-6">
            <form action="contact.php" method="post" role="form">
              <div class="row">
                <h6 style="text-align:center;">Enquire Now</h6><br>
                <div class="form-group mt-3">
                  Name<input type="text" class="form-control" name="name" id="subject" placeholder="" required>
                </div>
                <div class="form-group mt-3">
                  Email <input type="text" class="form-control" name="email" id="subject" placeholder="" required>
                </div>
              </div>
              <div class="form-group mt-3">
                Mobile Number<input type="text" class="form-control" name="mobile" id="subject" placeholder=""
                  required>
              </div>

              <!-- <div class="my-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div> -->
              <div class="text-center"><button type="submit" class="btn btn-dark">Submit</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-4 footer-newsletter">
            <img src="assets/images/logo/logo.png" style="margin-bottom: 10px;line-height: 10px;">
            <p>Gopalan Enterprises was founded in 1984 by Mr. C. Gopalan, an architect, with the objective of developing
              and constructing residential apartments in Bangalore. The company is one of the prominent real estate
              developers in Bangalore and has developed some of the finest residential apartments.</p>

          </div>
          <div class="col-lg-4 col-md-4 footer-links">
            <h4>Contact Details</h4>
            <ul>
              <li> <a href="#" style="color:orange;">Home</a></li>
              <li> <a href="#" style="color:orange;">Overview</a></li>
              <li> <a href="#" style="color:orange;">Configuration</a></li>
              <li> <a href="#" style="color:orange;">Amenities</a></li>
              <li> <a href="#" style="color:orange;">Gallery</a></li>
              <li> <a href="#" style="color:orange;">Contact</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-4 footer-links">
            <h4>Contact Details</h4>
            <ul>
              <li><a href="mailto:info@gopalanenterprises.com" style="color:orange;"><i
                    class="bx bx-envelope"></i>info@gopalanenterprises.com</a></li>
              <li><a href="tel:080 49314931" style="color:orange;"><i class="bx bx-mobile"></i>080 49314931</a></li>

              <table class="tableqr">
                <tr>
                  <th>Project</th>
                  <th>Testimonial</th>
                </tr>
                <tr>
                  <td><img src="assets/images/qr/project-page.jpg" class="qrimg"></td>
                  <td><img src="assets/images/qr/testimonial.jpg" class="qrimg"></td>
                </tr>
              </table>
            </ul>
          </div>



        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        Copyright © 2022 | <a href="#" style="color:orange;">gopalan enterprises</a>
      </div>

    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
      class="bi bi-arrow-up-short"></i></a>
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script>
    	$( window ).scroll(function() {

var height = $(window).scrollTop();

if(height >= 500) {
  $('.navbar').addClass('fixed-menu');
} else {
  $('.navbar').removeClass('fixed-menu');
}

});

$( ".append" ).append( "This" + height + "is!");
    </script>

</body>

</html>