<?php
$name=$_POST['name'];
$email = $_POST['email'];
$mobile=$_POST['mobile'];

$conn = mysqli_connect("localhost", "root","", "contactform") or die("connection fail");
$sql = "INSERT INTO form(name, email, mobile) VALUES('{$name}','{$email}', '{$mobile}')";
$result=mysqli_query($conn, $sql) or die("query failed");
header("location:thankyou.php");
mysqli_close($conn);

?>