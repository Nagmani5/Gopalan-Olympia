<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank you</title>
</head>
<body>
    <h5> Thank you for getting in touch! </h5>
    <p>We appreciate you contacting us. One of our colleagues will get back in touch with you soon!
        Have a great day!</p>
</body>
</html>